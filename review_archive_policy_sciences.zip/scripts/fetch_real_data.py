"""
Fetch real data from public APIs for canonical curves re-examination.

Data sources:
- World Bank WDI (via wbgapi): GDP per capita, life expectancy, Gini, CO2, etc.
- Representative published data for curves without direct API access

Anonymous Author 2026.
"""

import pandas as pd
import wbgapi as wb
import warnings
import os
import json

warnings.filterwarnings('ignore')

RESULTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'results')
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
os.makedirs(DATA_DIR, exist_ok=True)


def fetch_world_bank_data():
    """Fetch cross-country data from World Bank for multiple curves."""
    print("Fetching World Bank data...")

    # Indicators we need
    indicators = {
        'NY.GDP.PCAP.PP.KD': 'gdp_pc_ppp',           # GDP per capita, PPP (constant 2021 int'l $)
        'SP.DYN.LE00.IN': 'life_expectancy',          # Life expectancy at birth
        'SI.POV.GINI': 'gini',                        # Gini index
        'EN.ATM.CO2E.PC': 'co2_pc',                   # CO2 emissions (metric tons per capita)
        'SP.DYN.TFRT.IN': 'tfr',                      # Fertility rate, total
        'SH.DYN.MORT': 'child_mortality',             # Under-5 mortality rate
        'NE.CON.FOOD.ZS': 'food_expenditure_share',   # Food expenditure (% of total)
        'SP.POP.TOTL': 'population',                  # Population total
        'NY.GDP.MKTP.PP.KD': 'gdp_total',            # GDP, PPP (constant 2021 int'l $)
        'AG.LND.FRST.ZS': 'forest_pct',              # Forest area (% of land area)
        'SP.DYN.LE00.MA.IN': 'life_exp_male',        # Life expectancy male
        'SP.DYN.LE00.FE.IN': 'life_exp_female',      # Life expectancy female
    }

    # Fetch most recent year for each country (2020-2023)
    all_data = {}
    for ind_code, col_name in indicators.items():
        try:
            print(f"  Fetching {col_name} ({ind_code})...")
            # Get data for years 2018-2022 and take most recent non-null
            df = wb.data.DataFrame(ind_code, time=range(2018, 2023), labels=True)
            if not df.empty:
                # Take most recent available value for each country
                df_melted = df.reset_index()
                # The DataFrame has countries as rows and years as columns
                # Take the last non-null value
                if 'economy' in df_melted.columns:
                    df_melted = df_melted.set_index('economy')
                year_cols = [c for c in df_melted.columns if c.startswith('YR')]
                if year_cols:
                    df_melted['value'] = df_melted[year_cols].bfill(axis=1).iloc[:, 0]
                    all_data[col_name] = df_melted['value']
        except Exception as e:
            print(f"    Warning: Failed to fetch {col_name}: {e}")

    # Combine into a single DataFrame
    if all_data:
        combined = pd.DataFrame(all_data)
        combined.index.name = 'country_code'
        # Add country names
        try:
            economies = wb.economy.DataFrame()
            if 'name' in economies.columns:
                combined = combined.join(economies[['name', 'region', 'incomeLevel']])
        except Exception:
            pass

        output_path = os.path.join(DATA_DIR, 'world_bank_data.csv')
        combined.to_csv(output_path)
        print(f"  World Bank data saved: {output_path} ({len(combined)} countries)")
        return combined
    return None


def fetch_wb_time_series():
    """Fetch time series data for specific countries."""
    print("Fetching World Bank time series...")

    # US GDP growth and unemployment for Phillips/Okun
    try:
        # US GDP growth
        gdp_growth = wb.data.DataFrame('NY.GDP.MKTP.KD.ZG', economy='USA',
                                        time=range(1960, 2023), labels=True)
        # US unemployment (via ILO estimate)
        unemp = wb.data.DataFrame('SL.UEM.TOTL.ZS', economy='USA',
                                   time=range(1960, 2023), labels=True)
        # US inflation
        inflation = wb.data.DataFrame('FP.CPI.TOTL.ZG', economy='USA',
                                       time=range(1960, 2023), labels=True)

        us_macro = pd.DataFrame({
            'gdp_growth': gdp_growth.iloc[0] if not gdp_growth.empty else None,
            'unemployment': unemp.iloc[0] if not unemp.empty else None,
            'inflation': inflation.iloc[0] if not inflation.empty else None,
        })
        us_macro.to_csv(os.path.join(DATA_DIR, 'us_macro_timeseries.csv'))
        print("  US macro time series saved.")
    except Exception as e:
        print(f"  Warning: US macro fetch failed: {e}")

    # Global cereal yield for Green Revolution
    try:
        cereal = wb.data.DataFrame('AG.YLD.CREL.KG', economy='WLD',
                                    time=range(1961, 2023), labels=True)
        if not cereal.empty:
            cereal.to_csv(os.path.join(DATA_DIR, 'global_cereal_yield.csv'))
            print("  Global cereal yield saved.")
    except Exception as e:
        print(f"  Warning: cereal yield fetch failed: {e}")


def get_preston_data_real(wb_data):
    """Extract Preston Curve data from World Bank dataset."""
    if wb_data is None:
        return None
    mask = wb_data[['gdp_pc_ppp', 'life_expectancy']].notna().all(axis=1)
    df = wb_data[mask][['gdp_pc_ppp', 'life_expectancy']].copy()
    if 'name' in wb_data.columns:
        df['country'] = wb_data.loc[mask, 'name']
    df = df[df['gdp_pc_ppp'] > 0]
    return df


def get_kuznets_data_real(wb_data):
    """Extract Kuznets Curve data from World Bank dataset."""
    if wb_data is None:
        return None
    mask = wb_data[['gdp_pc_ppp', 'gini']].notna().all(axis=1)
    df = wb_data[mask][['gdp_pc_ppp', 'gini']].copy()
    if 'name' in wb_data.columns:
        df['country'] = wb_data.loc[mask, 'name']
    df = df[df['gdp_pc_ppp'] > 0]
    return df


def get_ekc_data_real(wb_data):
    """Extract EKC data from World Bank dataset."""
    if wb_data is None:
        return None
    required = ['gdp_pc_ppp', 'co2_pc']
    available = [c for c in required if c in wb_data.columns]
    if len(available) < 2:
        print("    EKC: co2_pc not available from API, skipping real data extraction")
        return None
    mask = wb_data[required].notna().all(axis=1)
    df = wb_data[mask][required].copy()
    if 'name' in wb_data.columns:
        df['country'] = wb_data.loc[mask, 'name']
    df = df[(df['gdp_pc_ppp'] > 0) & (df['co2_pc'] > 0)]
    return df


def get_demographic_transition_real(wb_data):
    """Extract Demographic Transition data."""
    if wb_data is None:
        return None
    mask = wb_data[['gdp_pc_ppp', 'tfr']].notna().all(axis=1)
    df = wb_data[mask][['gdp_pc_ppp', 'tfr']].copy()
    if 'name' in wb_data.columns:
        df['country'] = wb_data.loc[mask, 'name']
    df = df[df['gdp_pc_ppp'] > 0]
    return df


def get_forest_transition_real(wb_data):
    """Extract Forest Transition data."""
    if wb_data is None:
        return None
    mask = wb_data[['gdp_pc_ppp', 'forest_pct']].notna().all(axis=1)
    df = wb_data[mask][['gdp_pc_ppp', 'forest_pct']].copy()
    if 'name' in wb_data.columns:
        df['country'] = wb_data.loc[mask, 'name']
    df = df[df['gdp_pc_ppp'] > 0]
    return df


def create_source_metadata():
    """Create comprehensive source metadata for all 52 curves."""
    sources = [
        # Economics (1-12)
        {"id": 1, "name": "Phillips Curve", "category": "Economics",
         "original_paper": "Phillips AW (1958) Economica 25:283-299",
         "original_n": 61, "original_period": "1861-1957",
         "data_source": "World Bank WDI: SL.UEM.TOTL.ZS, FP.CPI.TOTL.ZG",
         "current_n": None, "current_period": "1960-2022",
         "x_variable": "Unemployment rate (%)", "y_variable": "Inflation rate (CPI, %)",
         "claimed_form": "Negative convex", "country_scope": "USA (time series)"},
        {"id": 2, "name": "Laffer Curve", "category": "Economics",
         "original_paper": "Laffer A (1974) unpublished (napkin sketch)",
         "original_n": 0, "original_period": "Theoretical",
         "data_source": ("OECD Tax Database Table I.7 (top personal income tax "
                         "rate, PERS_ITAX) + OECD Global Revenue Statistics "
                         "(total tax as % of GDP)"),
         "current_n": None, "current_period": "2022 cross-section",
         "x_variable": "Top marginal personal income tax rate (%)",
         "y_variable": "Total tax revenue (% of GDP)",
         "claimed_form": "Inverted-U", "country_scope": "OECD countries"},
        {"id": 3, "name": "Kuznets Curve", "category": "Economics",
         "original_paper": "Kuznets S (1955) Am Econ Rev 45:1-28",
         "original_n": 3, "original_period": "3 countries, historical",
         "data_source": "World Bank WDI: NY.GDP.PCAP.PP.KD, SI.POV.GINI",
         "current_n": None, "current_period": "2018-2022",
         "x_variable": "GDP per capita PPP ($)", "y_variable": "Gini coefficient",
         "claimed_form": "Inverted-U", "country_scope": "Global cross-section"},
        {"id": 4, "name": "Environmental Kuznets Curve (CO2)", "category": "Economics",
         "original_paper": "Grossman GM, Krueger AB (1991) NBER WP 3914",
         "original_n": 42, "original_period": "1977-1988",
         "data_source": "World Bank WDI: NY.GDP.PCAP.PP.KD, EN.ATM.CO2E.PC",
         "current_n": None, "current_period": "2018-2022",
         "x_variable": "GDP per capita PPP ($)", "y_variable": "CO2 per capita (tonnes)",
         "claimed_form": "Inverted-U", "country_scope": "Global cross-section"},
        {"id": 5, "name": "Beveridge Curve", "category": "Economics",
         "original_paper": "Beveridge W (1944) Full Employment in a Free Society",
         "original_n": 20, "original_period": "1920s-1940s UK",
         "data_source": "US BLS API: CPS unemployment (LNS14000000) + JOLTS job openings rate (JTS...JOR), annual means",
         "current_n": None, "current_period": "BLS annual means (2001-present)",
         "x_variable": "Unemployment rate (%)", "y_variable": "Vacancy rate (%)",
         "claimed_form": "Negative convex (hyperbolic)", "country_scope": "USA (time series)"},
        {"id": 6, "name": "Okun's Law", "category": "Economics",
         "original_paper": "Okun AM (1962) Proceedings of the Business and Economic Statistics Section, ASA",
         "original_n": 16, "original_period": "1947-1960",
         "data_source": "World Bank WDI: NY.GDP.MKTP.KD.ZG, SL.UEM.TOTL.ZS",
         "current_n": None, "current_period": "1960-2022",
         "x_variable": "Real GDP growth (%)", "y_variable": "Change in unemployment (pp)",
         "claimed_form": "Linear (nonlinear extension tested)", "country_scope": "USA (time series)"},
        {"id": 7, "name": "Engel Curve", "category": "Economics",
         "original_paper": "Engel E (1857) Die Produktions- und Consumtionsverhältnisse des Königreichs Sachsen",
         "original_n": 153, "original_period": "1857 Saxony households",
         "data_source": "OWID food expenditure share (USDA ERS) + World Bank WDI GDP per capita PPP, matched by ISO3",
         "current_n": None, "current_period": "most recent common year per country (2010-2023)",
         "x_variable": "GDP per capita PPP ($)", "y_variable": "Food expenditure share (%)",
         "claimed_form": "Concave (decreasing share)", "country_scope": "Global cross-section"},
        {"id": 8, "name": "J-Curve (Trade)", "category": "Economics",
         "original_paper": "Magee SP (1973) The Balance of Payments. Brookings Papers",
         "original_n": 6, "original_period": "Post-devaluation episodes",
         "data_source": ("World Bank WDI: PX.REX.REER (US real effective exchange rate) + "
                         "NE.RSB.GNFS.ZS (US external balance %GDP), years since the 1985 "
                         "REER peak; RECONSTRUCTION of the post-Plaza-Accord depreciation "
                         "episode (peak year chosen from the data, not hard-coded; "
                         "annual, not the textbook stylized quarterly episode)"),
         "current_n": None, "current_period": "US annual, 1985 (REER peak) to 2000",
         "x_variable": "Years since real-exchange-rate peak", "y_variable": "Trade balance (% of GDP)",
         "claimed_form": "J-shaped (initial deterioration then improvement)", "country_scope": "US post-1985 episode"},
        {"id": 9, "name": "Rahn Curve", "category": "Economics",
         "original_paper": "Rahn RW (1996) Institute for Policy Innovation",
         "original_n": 20, "original_period": "OECD 1960-1996",
         "data_source": "OWID historical government expenditure (IMF general govt) + World Bank WDI real GDP growth, 2010-2019 means",
         "current_n": None, "current_period": "2010-2019 decade means",
         "x_variable": "Government spending (% of GDP)", "y_variable": "Real GDP growth (%)",
         "claimed_form": "Inverted-U (peak at 15-25%)", "country_scope": "Global cross-section"},
        {"id": 10, "name": "Gravity Model of Trade", "category": "Economics",
         "original_paper": "Tinbergen J (1962) Shaping the World Economy",
         "original_n": 42, "original_period": "1958 bilateral trade",
         "data_source": "CEPII Gravity database V202211 (GDP_o, GDP_d, dist, BACI bilateral trade), ordered country pairs 2019",
         "current_n": None, "current_period": "2019 (all valid ordered country pairs)",
         "x_variable": "log(GDP_i × GDP_j / Distance²)", "y_variable": "log(Bilateral trade)",
         "claimed_form": "Power law (log-linear)", "country_scope": "Global bilateral pairs"},
        {"id": 11, "name": "Great Gatsby Curve", "category": "Economics",
         "original_paper": "Corak M (2013) J Econ Perspect 27(3):79-102",
         "original_n": 22, "original_period": "~2010 cross-section",
         "data_source": ("Reconstruction: World Bank GDIM income mobility IGE "
                         "(Munoz & van der Weide 2025, WP 11166) + OWID/World "
                         "Bank Gini index (PIP). Not the original Corak figure."),
         "current_n": None, "current_period": "Latest Gini per country (2000-2022)",
         "x_variable": "Gini coefficient", "y_variable": "Intergenerational income elasticity (IGE)",
         "claimed_form": "Positive (possibly convex)", "country_scope": "87-economy GDIM cross-section"},
        {"id": 12, "name": "Balassa-Samuelson Effect", "category": "Economics",
         "original_paper": "Balassa B (1964) J Political Economy 72:584-596",
         "original_n": 12, "original_period": "1960s cross-section",
         "data_source": "Penn World Table 10.01: productivity (rgdpo/emp) and price level (pl_gdpo)",
         "current_n": None, "current_period": "latest PWT year (relative to USA)",
         "x_variable": "Relative labor productivity (US=100)", "y_variable": "Relative price level",
         "claimed_form": "Positive linear/log", "country_scope": "Global cross-section"},

        # Public Health (13-22)
        {"id": 13, "name": "Preston Curve", "category": "Public Health",
         "original_paper": "Preston SH (1975) Popul Stud 29:231-248",
         "original_n": 30, "original_period": "1900s, 1930s, 1960s cohorts",
         "data_source": "World Bank WDI: NY.GDP.PCAP.PP.KD, SP.DYN.LE00.IN",
         "current_n": None, "current_period": "2018-2022",
         "x_variable": "GDP per capita PPP ($)", "y_variable": "Life expectancy (years)",
         "claimed_form": "Concave (log-linear)", "country_scope": "Global cross-section"},
        {"id": 14, "name": "Easterlin Paradox", "category": "Public Health",
         "original_paper": "Easterlin RA (1974) in Nations and Households in Economic Growth",
         "original_n": 14, "original_period": "1960s cross-section",
         "data_source": "OWID Cantril ladder (World Happiness Report / Gallup) + World Bank WDI GDP per capita PPP, matched by ISO3",
         "current_n": None, "current_period": "most recent common year per country (2010-2023)",
         "x_variable": "GDP per capita PPP ($)", "y_variable": "Happiness score (0-10)",
         "claimed_form": "Concave/saturating", "country_scope": "Global cross-section"},
        {"id": 15, "name": "McKeown Thesis (TB Mortality)", "category": "Public Health",
         "original_paper": "McKeown T (1976) The Modern Rise of Population. Edward Arnold",
         "original_n": 12, "original_period": "1840-1960",
         "data_source": ("McKeown, Record & Turner (1975) Population Studies 29(3):391-422, "
                         "Table 4: respiratory tuberculosis standardized death rate per million "
                         "(England & Wales, age/sex-standardized to 1901), decades 1901-1971; "
                         "transcribed (see data/digitized_sources.md)"),
         "current_n": None, "current_period": "England & Wales, 1901-1971 (decadal)",
         "x_variable": "Year", "y_variable": "Respiratory TB deaths per million (std. to 1901)",
         "claimed_form": "Exponential decline", "country_scope": "England & Wales (time series)"},
        {"id": 16, "name": "Linear No-Threshold (LNT)", "category": "Public Health",
         "original_paper": "ICRP (1958) Publication 1; Ozasa et al. (2012) Radiat Res 177:229-243",
         "original_n": 86611, "original_period": "1950-2003 (LSS cohort)",
         "data_source": "Ozasa et al. (2012) Radiat Res 177:229-243, Fig. 4 (erratum-corrected low-dose point), ERR vs weighted colon dose; digitized (see data/digitized_sources.md)",
         "current_n": None, "current_period": "LSS Fig. 4 dose points (erratum-corrected)",
         "x_variable": "Weighted colon dose (Gy)", "y_variable": "Excess relative risk (ERR)",
         "claimed_form": "Linear (threshold debate)", "country_scope": "Hiroshima/Nagasaki survivors"},
        {"id": 17, "name": "Fries Compression of Morbidity", "category": "Public Health",
         "original_paper": "Fries JF (1980) N Engl J Med 303:130-135",
         "original_n": 0, "original_period": "Theoretical (1980)",
         "data_source": "Fries JF (1980) NEJM 303:130-135, Fig. 2 (idealized US 1980 survival curve, % surviving vs age); digitized. NOTE: variable definition changed from the previous 'year vs morbidity duration', which matched no figure/table in Fries 1980 (see data/digitized_sources.md)",
         "current_n": None, "current_period": "Fig. 2 survival curve (US 1980)",
         "x_variable": "Age (years)", "y_variable": "% surviving (US 1980)",
         "claimed_form": "Compression (declining morbidity period)", "country_scope": "USA (time series)"},
        {"id": 18, "name": "Barker Hypothesis (U-shape)", "category": "Public Health",
         "original_paper": "Barker DJP (1990) BMJ 301:1111",
         "original_n": 5654, "original_period": "1911-1930 birth cohort",
         "data_source": "Osmond, Barker, Winter, Fall & Simmonds (1993) BMJ 307:1519-1524, Tables I-II (SMR all cardiovascular disease by birth weight, women+men); transcribed (see data/digitized_sources.md)",
         "current_n": None, "current_period": "Birth-weight categories, women+men",
         "x_variable": "Birth weight (kg)", "y_variable": "SMR (all cardiovascular disease)",
         "claimed_form": "U-shaped (NOT supported: source is monotonically decreasing)", "country_scope": "UK birth cohorts"},
        {"id": 19, "name": "Omran Epidemiological Transition", "category": "Public Health",
         "original_paper": "Omran AR (1971) Milbank Mem Fund Q 49:509-538",
         "original_n": 5, "original_period": "Historical model (3 stages)",
         "data_source": "UNDP HDI (composite index) + World Bank WDI SH.DTH.NCOM.ZS (NCD mortality)",
         "current_n": None, "current_period": "latest HDI + WDI NCD share",
         "x_variable": "Human Development Index", "y_variable": "NCD deaths (% of total)",
         "claimed_form": "S-shaped transition", "country_scope": "Global cross-section"},
        {"id": 20, "name": "Wilkinson Curve", "category": "Public Health",
         "original_paper": "Wilkinson RG (1996) Unhealthy Societies. Routledge",
         "original_n": 12, "original_period": "1990s OECD",
         "data_source": "Wilkinson RG (1992) BMJ 304:165-168, Fig. 2 (life expectancy vs % income to least well-off 70%, 9 OECD countries); digitized (see data/digitized_sources.md)",
         "current_n": None, "current_period": "Fig. 2, 9 OECD countries (c.1980s)",
         "x_variable": "% income to least well-off 70%", "y_variable": "Life expectancy (years)",
         "claimed_form": "Positive (income equality → longevity)", "country_scope": "9 OECD countries"},
        {"id": 21, "name": "BMI-Mortality J-Curve", "category": "Public Health",
         "original_paper": "Various; Global BMI Mortality Collaboration (2016) Lancet 388:776-786",
         "original_n": 10625411, "original_period": "Pooled cohorts",
         "data_source": "Global BMI Mortality Collaboration (2016) Lancet 388:776-786, primary analysis HRs by 9 BMI groups (transcribed; see data/digitized_sources.md)",
         "current_n": None, "current_period": "9 BMI groups (primary never-smoker analysis)",
         "x_variable": "BMI (kg/m²)", "y_variable": "Relative risk (all-cause mortality)",
         "claimed_form": "J-shaped (nadir at BMI 22-25)", "country_scope": "Global pooled cohorts"},
        {"id": 22, "name": "Alcohol-Mortality J-Curve", "category": "Public Health",
         "original_paper": "Di Castelnuovo A et al. (2006) Arch Intern Med 166:2437-2445",
         "original_n": 1015835, "original_period": "34 prospective studies (meta-analysis)",
         "data_source": "Di Castelnuovo et al. (2006) Arch Intern Med 166:2437-2445, pooled fixed-effects dose-response (RR all-cause mortality vs g/day); digitized (see data/digitized_sources.md)",
         "current_n": None, "current_period": "Pooled dose-response curve",
         "x_variable": "Alcohol intake (g/day)", "y_variable": "Relative risk (all-cause mortality)",
         "claimed_form": "J-shaped (moderate drinking protective?)", "country_scope": "Global meta-analysis"},

        # Demography (23-28)
        {"id": 23, "name": "Demographic Transition Model", "category": "Demography",
         "original_paper": "Notestein FW (1945) in Population: The Long View",
         "original_n": 5, "original_period": "European historical model",
         "data_source": "World Bank WDI: SP.DYN.TFRT.IN; UNDP HDI",
         "current_n": None, "current_period": "2020-2022",
         "x_variable": "Human Development Index", "y_variable": "Total fertility rate",
         "claimed_form": "S-shaped decline", "country_scope": "Global cross-section"},
        {"id": 24, "name": "Bongaarts-Feeney Tempo Adjustment", "category": "Demography",
         "original_paper": "Bongaarts J, Feeney G (1998) Popul Dev Rev 24:271-291",
         "original_n": 15, "original_period": "1970-1995 select countries",
         "data_source": "Bongaarts & Feeney (1998) Popul Dev Rev 24:271-291, Fig. 3 (observed vs tempo-adjusted TFR, US 1950-90); digitized (see data/digitized_sources.md)",
         "current_n": None, "current_period": "US 1950-1990",
         "x_variable": "Tempo-adjusted TFR (births/woman)", "y_variable": "Observed TFR (births/woman)",
         "claimed_form": "Tempo distortion (observed vs quantum)", "country_scope": "USA (time series)"},
        {"id": 25, "name": "Lee-Carter Mortality Model", "category": "Demography",
         "original_paper": "Lee RD, Carter LR (1992) J Am Stat Assoc 87:659-671",
         "original_n": 89, "original_period": "1900-1989 USA",
         "data_source": "HMD USA period death rates (Mx_1x1); kappa_t estimated by Lee-Carter SVD (raw HMD data not redistributed)",
         "current_n": None, "current_period": "HMD USA years with full age coverage (1933-present)",
         "x_variable": "Year", "y_variable": "Mortality index (κ_t)",
         "claimed_form": "Linear decline (structural change tested)", "country_scope": "USA (time series)"},
        {"id": 26, "name": "Coale-Trussell Fertility Schedule", "category": "Demography",
         "original_paper": "Coale AJ, Trussell TJ (1974) Popul Index 40:185-258",
         "original_n": 43, "original_period": "Natural fertility populations",
         "data_source": "Coale & Trussell (1974/1978) Population Index 40(2):185-258, standard natural-fertility schedule n(a); public-domain table transcription (see data/digitized_sources.md)",
         "current_n": None, "current_period": "5-year age groups 20-49",
         "x_variable": "Age (midpoint of 5-year group)", "y_variable": "Natural-fertility standard n(a)",
         "claimed_form": "Concave decline with age", "country_scope": "Natural fertility schedule (Hutterites)"},
        {"id": 27, "name": "Replacement Migration Curve", "category": "Demography",
         "original_paper": "UN Population Division (2000) Replacement Migration",
         "original_n": 8, "original_period": "Projections for 8 countries",
         "data_source": ("UN (2000) 'Replacement Migration' report, Table IV.1 "
                         "(TFR 1995-2000) and Table IV.6 (Scenario IV migrants "
                         "per million, constant working-age pop). MODEL OUTPUTS."),
         "current_n": None, "current_period": "UN projection 2000-2050 (Scenario IV)",
         "x_variable": "TFR gap below replacement (2.1 - TFR)",
         "y_variable": "Required net migration, Scenario IV (per million/yr)",
         "claimed_form": "Nonlinear increase", "country_scope": "8 UN study countries"},
        {"id": 28, "name": "Second Demographic Transition", "category": "Demography",
         "original_paper": "Van de Kaa DJ (1987) Popul Bull 42(1):1-57",
         "original_n": 12, "original_period": "Western Europe 1960s-1980s",
         "data_source": "World Bank WDI: SP.DYN.TFRT.IN; UNDP HDI",
         "current_n": 30, "current_period": "2022-2023",
         "x_variable": "Human Development Index", "y_variable": "Total fertility rate",
         "claimed_form": "J-shaped recovery at high HDI (debated)", "country_scope": "Developed countries"},

        # Environmental Science (29-34)
        {"id": 29, "name": "Species-Area Curve", "category": "Environmental Science",
         "original_paper": "Arrhenius O (1921) J Ecol 9:95-99",
         "original_n": 20, "original_period": "Swedish plant communities",
         "data_source": "Johnson & Raven (1973) Science 179:893-895, Galapagos archipelago plant species vs island area (faraway 'gala' dataset; see data/digitized_sources.md)",
         "current_n": None, "current_period": "30 Galapagos islands (plant species vs area)",
         "x_variable": "log₁₀(Area, km²)", "y_variable": "log₁₀(Species count)",
         "claimed_form": "Power law S = cA^z (z ≈ 0.25)", "country_scope": "Galapagos archipelago (30 islands)"},
        {"id": 30, "name": "Hubbert Peak Oil", "category": "Environmental Science",
         "original_paper": "Hubbert MK (1956) Nuclear Energy and the Fossil Fuels. API",
         "original_n": 25, "original_period": "US production 1900-1956 + projection",
         "data_source": "US EIA Total Energy: crude oil production (MSN=PAPRPUS)",
         "current_n": None, "current_period": "EIA annual series (1949-present)",
         "x_variable": "Year", "y_variable": "US crude oil production (thousand bbl/day)",
         "claimed_form": "Symmetric bell curve (logistic derivative)", "country_scope": "USA (time series)"},
        {"id": 31, "name": "Keeling Curve (CO2)", "category": "Environmental Science",
         "original_paper": "Keeling CD (1960) Tellus 12:200-203",
         "original_n": 2, "original_period": "1958-1960 (initial)",
         "data_source": "NOAA Global Monitoring Laboratory: Mauna Loa CO2 annual means",
         "current_n": None, "current_period": "NOAA Mauna Loa annual means (1959-present)",
         "x_variable": "Year", "y_variable": "CO₂ concentration (ppm)",
         "claimed_form": "Accelerating (super-linear) increase", "country_scope": "Global (Mauna Loa)"},
        {"id": 32, "name": "HANPP", "category": "Environmental Science",
         "original_paper": "Vitousek PM et al. (1986) BioScience 36:368-373",
         "original_n": 0, "original_period": "Global estimate (1986)",
         "data_source": ("Haberl et al. (2007) PNAS gridded HANPP/NPP0 "
                         "(year 2000), aggregated to countries by zonal "
                         "statistics (Natural Earth admin-0) + OWID/World "
                         "Bank GDP per capita PPP (2000)"),
         "current_n": None, "current_period": "Year 2000",
         "x_variable": "GDP per capita PPP ($)", "y_variable": "HANPP (% of NPP0)",
         "claimed_form": "EKC-like inverted-U (debated)", "country_scope": "Global cross-section"},
        {"id": 33, "name": "Jevons Paradox (Energy)", "category": "Environmental Science",
         "original_paper": "Jevons WS (1865) The Coal Question. Macmillan",
         "original_n": 0, "original_period": "UK coal 1830-1865 (qualitative)",
         "data_source": "US EIA Total Energy (MSN=TETCBUS) + World Bank WDI US real GDP (intensity)",
         "current_n": None, "current_period": "EIA/WDI annual overlap (1960-present)",
         "x_variable": "Energy intensity (Btu per real $ GDP)", "y_variable": "Total primary energy consumption (Trillion Btu)",
         "claimed_form": "Negative (efficiency increase → consumption increase)", "country_scope": "USA (time series)"},
        {"id": 34, "name": "Forest Transition Curve", "category": "Environmental Science",
         "original_paper": "Mather AS (1992) Area 24:367-379",
         "original_n": 10, "original_period": "Historical European data",
         "data_source": "World Bank WDI: NY.GDP.PCAP.PP.KD, AG.LND.FRST.ZS",
         "current_n": None, "current_period": "2018-2022",
         "x_variable": "GDP per capita PPP ($)", "y_variable": "Forest area (% of land)",
         "claimed_form": "U-shaped (deforestation then recovery)", "country_scope": "Global cross-section"},

        # Psychology (36, 38, 39); #35 Yerkes-Dodson and #37 Weber-Fechner
        # excluded (synthetic / hand-typed arrays; no traceable primary dataset)
        {"id": 36, "name": "Ebbinghaus Forgetting Curve", "category": "Psychology",
         "original_paper": "Ebbinghaus H (1885) Über das Gedächtnis",
         "original_n": 1, "original_period": "1879-1880 (self-experimentation)",
         "data_source": "Ebbinghaus (1885) Memory, Ch.VII Section 28-29 original savings table (7 relearning intervals; public domain; see data/digitized_sources.md)",
         "current_n": None, "current_period": "7 relearning intervals (0.33h-31 days), 1879-80",
         "x_variable": "log(Time in hours)", "y_variable": "Retention (%)",
         "claimed_form": "Exponential or power-law decay", "country_scope": "Laboratory replications"},
        {"id": 38, "name": "Dunning-Kruger Effect", "category": "Psychology",
         "original_paper": "Kruger J, Dunning D (1999) J Pers Soc Psychol 77:1121-1134",
         "original_n": 334, "original_period": "Cornell undergraduates 1990s",
         "data_source": "Kruger & Dunning (1999) JPSP 77:1121-1134, Figs. 1-4 (perceived ability vs actual percentile, Studies 1-4); digitized (see data/digitized_sources.md)",
         "current_n": None, "current_period": "4 quartiles x 4 studies",
         "x_variable": "Actual performance (percentile)", "y_variable": "Self-assessed ability (percentile)",
         "claimed_form": "Quadratic (low performers overestimate most)", "country_scope": "Laboratory experiments"},
        {"id": 39, "name": "Happiness U-Curve (Age)", "category": "Psychology",
         "original_paper": "Stone, Schwartz, Broderick & Deaton (2010) PNAS 107(22):9985-9990",
         "original_n": 340847, "original_period": "Gallup 2008 (USA)",
         "data_source": "Stone et al. (2010) PNAS 107:9985-9990, Fig. 1 (Global WB Cantril ladder by 4-yr age group, unadjusted 'Age alone'); digitized (see data/digitized_sources.md)",
         "current_n": None, "current_period": "17 4-year age groups (18-85)",
         "x_variable": "Age (midpoint of 4-year group)", "y_variable": "Global well-being (Cantril ladder, 0-10)",
         "claimed_form": "U-shaped (nadir age 50-53)", "country_scope": "USA cross-section (N=340,847)"},

        # Physics (40-43)
        {"id": 40, "name": "Hubble's Law", "category": "Physics",
         "original_paper": "Hubble E (1929) Proc Natl Acad Sci 15:168-173",
         "original_n": 24, "original_period": "1920s nebulae observations",
         "data_source": "Hubble E (1929) PNAS 15:168-173, Table 1 (24 nebulae, public domain); distance vs recession velocity",
         "current_n": None, "current_period": "1920s nebulae observations (original data)",
         "x_variable": "Distance (Mpc)", "y_variable": "Recession velocity (km/s)",
         "claimed_form": "Linear (v = H₀d); nonlinear acceleration at high z", "country_scope": "Local universe galaxies"},
        {"id": 41, "name": "Kleiber's Law", "category": "Physics",
         "original_paper": "Kleiber M (1932) Hilgardia 6:315-353",
         "original_n": 9, "original_period": "1930s domestic animals",
         "data_source": "AnAge database (Human Ageing Genomic Resources; Tacutu et al. 2018 Nucleic Acids Res): metabolic rate (W) and body mass for 422 mammal species (see data/digitized_sources.md)",
         "current_n": None, "current_period": "422 extant mammal species (AnAge build 14)",
         "x_variable": "log₁₀(Body mass, kg)", "y_variable": "log₁₀(BMR, Watts)",
         "claimed_form": "Power law B ∝ M^0.75 (3/4 scaling)", "country_scope": "Mammalia (422 species)"},
        {"id": 42, "name": "Gutenberg-Richter Law", "category": "Physics",
         "original_paper": "Gutenberg B, Richter CF (1944) Bull Seismol Soc Am 34:185-188",
         "original_n": 0, "original_period": "1930s-1940s California seismicity",
         "data_source": "USGS Earthquake Catalog (ComCat); ISC-GEM Global Instrumental Catalogue",
         "current_n": None, "current_period": "USGS FDSN catalog, 2000-2020 annualized",
         "x_variable": "Magnitude", "y_variable": "log₁₀(Annual frequency)",
         "claimed_form": "Log-linear (power law in energy)", "country_scope": "Global seismicity"},
        {"id": 43, "name": "Moore's Law", "category": "Physics",
         "original_paper": "Moore GE (1965) Electronics 38:114-117",
         "original_n": 4, "original_period": "1959-1965",
         "data_source": "Karl Rupp semiconductor database; Wikipedia transistor count list (verified against datasheets)",
         "current_n": None, "current_period": "Karl Rupp transistor-count dataset (1971-present)",
         "x_variable": "Year", "y_variable": "log₁₀(Transistor count)",
         "claimed_form": "Exponential (linear in log scale)", "country_scope": "Global semiconductor industry"},

        # Political Science (44-48)
        {"id": 44, "name": "Lipset Hypothesis", "category": "Political Science",
         "original_paper": "Lipset SM (1959) Am Polit Sci Rev 53:69-105",
         "original_n": 48, "original_period": "1950s cross-section",
         "data_source": "World Bank WDI GDP per capita PPP + Freedom House FIW aggregate score",
         "current_n": None, "current_period": "latest WDI GDP + Freedom House edition",
         "x_variable": "GDP per capita PPP ($)", "y_variable": "Democracy score (Freedom House, 0-1)",
         "claimed_form": "Positive (possibly S-shaped or concave)", "country_scope": "Global cross-section"},
        {"id": 45, "name": "Duverger's Law", "category": "Political Science",
         "original_paper": "Duverger M (1954) Political Parties. Wiley",
         "original_n": 20, "original_period": "Western democracies 1950s",
         "data_source": "Bormann & Golder, Democratic Electoral Systems (DES) 5.0 (Electoral Studies 2022): tier-1 average district magnitude vs effective number of electoral parties, legislative elections (see data/digitized_sources.md)",
         "current_n": None, "current_period": "Legislative elections in democracies, 1919-2020",
         "x_variable": "log(District magnitude + 1)", "y_variable": "Effective number of electoral parties",
         "claimed_form": "Positive log-linear", "country_scope": "Democracies worldwide (DES 5.0)"},
        {"id": 46, "name": "Zipf's Law (US Cities)", "category": "Political Science",
         "original_paper": "Zipf GK (1949) Human Behavior and the Principle of Least Effort",
         "original_n": 100, "original_period": "US cities 1940s",
         "data_source": "US Census Bureau 2020 Decennial (dec/pl) place populations (P1_001N), API",
         "current_n": None, "current_period": "2020 (top places by population)",
         "x_variable": "log(Rank)", "y_variable": "log(Population)",
         "claimed_form": "Power law (exponent ≈ -1)", "country_scope": "USA largest places"},
        {"id": 47, "name": "Crime-Temperature Curve", "category": "Political Science",
         "original_paper": "Anderson CA (1987) J Pers Soc Psychol 52:1161-1173",
         "original_n": 48, "original_period": "US cities 1971-1980",
         "data_source": "FBI UCR data; NOAA climate normals; Ranson (2014) J Environ Econ Manage",
         "current_n": 16, "current_period": "Temperature bins (monthly aggregated)",
         "x_variable": "Temperature (°F)", "y_variable": "Violent crime rate index",
         "claimed_form": "Nonlinear (inverted-U at extreme heat)", "country_scope": "USA (monthly panel)"},
        {"id": 48, "name": "Putnam Social Capital", "category": "Political Science",
         "original_paper": "Putnam RD (2000) Bowling Alone. Simon & Schuster",
         "original_n": 50, "original_period": "US states + cross-national",
         "data_source": ("Proxy reconstruction: Eurostat HETUS time-use "
                         "(tus_00age, AC82 TV & video) + OWID generalized "
                         "trust (WVS/integrated surveys). Not a direct "
                         "Putnam replication."),
         "current_n": None, "current_period": "HETUS 2000/2010 rounds",
         "x_variable": "Daily TV viewing (hours)", "y_variable": "Generalized social trust (%)",
         "claimed_form": "Negative (possibly nonlinear)", "country_scope": "European proxy (22 countries)"},

        # Agriculture (49-52)
        {"id": 49, "name": "Mitscherlich Yield Curve", "category": "Agriculture",
         "original_paper": "Mitscherlich EA (1909) Landwirtschaftliche Jahrbücher 38:537-552",
         "original_n": 30, "original_period": "German field trials 1900s",
         "data_source": ("Engelstad & Parks (1971) Agronomy Journal 63:21-23, corn "
                         "N-response (2 Tennessee locations x 5 years x 6 N rates; "
                         "agridat::engelstad.nitro via Rdatasets); RECONSTRUCTION of "
                         "the diminishing-returns form, NOT Mitscherlich's original "
                         "1909 data (see data/digitized_sources.md)"),
         "current_n": None, "current_period": "Tennessee 1962-1966, 6 N rates",
         "x_variable": "Nitrogen fertilizer (kg/ha)", "y_variable": "Corn yield (quintals/ha)",
         "claimed_form": "Diminishing returns (asymptotic)", "country_scope": "US (Tennessee) N-response trial"},
        {"id": 50, "name": "Green Revolution Yield Curve", "category": "Agriculture",
         "original_paper": "Borlaug NE (1960s) various; Evenson & Gollin (2003) Science",
         "original_n": 40, "original_period": "1961-2000",
         "data_source": "World Bank WDI: AG.YLD.CREL.KG (Global cereal yield)",
         "current_n": None, "current_period": "1961-2022",
         "x_variable": "Year", "y_variable": "Global cereal yield (tonnes/ha)",
         "claimed_form": "S-shaped (logistic growth with saturation)", "country_scope": "Global average"},
        {"id": 51, "name": "Micronutrient U-shape (Vitamin D)", "category": "Agriculture",
         "original_paper": "Durup et al. (2012) J Clin Endocrinol Metab 97:2644-2652",
         "original_n": 247574, "original_period": "Danish cohort 2004-2007",
         "data_source": "Durup et al. (2012) J Clin Endocrinol Metab 97:2644-2652 (CopD study), Fig. 1A central spline (HR all-cause mortality vs 25(OH)D, ref 50 nmol/L); digitized (see data/digitized_sources.md)",
         "current_n": None, "current_period": "Fig. 1A spline (5-150 nmol/L)",
         "x_variable": "Serum 25(OH)D (nmol/L)", "y_variable": "Hazard ratio (all-cause mortality)",
         "claimed_form": "U-shaped (deficiency and excess both harmful)", "country_scope": "Global meta-analysis"},
        {"id": 52, "name": "Body Weight Set-Point", "category": "Agriculture",
         "original_paper": "Keesey RE, Hirvonen MD (1997) Am J Clin Nutr 66:1026-1032",
         "original_n": 0, "original_period": "Theoretical + small experiments",
         "data_source": "Leibel, Rosenbaum & Hirsch (1995) NEJM 332:621-628, Fig. 2 (observed-minus-predicted TEE vs body-weight change); digitized. NOTE: variable definition changed from the previous 'caloric change vs weight change' (see data/digitized_sources.md)",
         "current_n": None, "current_period": "Fig. 2 weight conditions (+10% to -20%)",
         "x_variable": "Body-weight change (%)", "y_variable": "Observed-minus-predicted TEE (kcal/day)",
         "claimed_form": "Nonlinear (resistance to weight change)", "country_scope": "Controlled feeding experiments"},
    ]

    # Save as JSON and CSV
    df = pd.DataFrame(sources)
    df.to_csv(os.path.join(DATA_DIR, 'source_metadata.csv'), index=False)
    with open(os.path.join(DATA_DIR, 'source_metadata.json'), 'w', encoding='utf-8') as f:
        json.dump(sources, f, indent=2, ensure_ascii=False)

    print(f"Source metadata saved: {len(sources)} curves")
    return sources


def main():
    print("=" * 60)
    print("FETCHING REAL DATA FOR CANONICAL CURVES RE-EXAMINATION")
    print("=" * 60)

    # 1. Fetch World Bank cross-country data
    wb_data = fetch_world_bank_data()

    # 2. Fetch time series
    fetch_wb_time_series()

    # 3. Extract specific curve datasets
    if wb_data is not None:
        datasets = {}

        preston = get_preston_data_real(wb_data)
        if preston is not None:
            preston.to_csv(os.path.join(DATA_DIR, 'preston_curve_real.csv'))
            datasets['preston'] = len(preston)

        kuznets = get_kuznets_data_real(wb_data)
        if kuznets is not None:
            kuznets.to_csv(os.path.join(DATA_DIR, 'kuznets_curve_real.csv'))
            datasets['kuznets'] = len(kuznets)

        ekc = get_ekc_data_real(wb_data)
        if ekc is not None:
            ekc.to_csv(os.path.join(DATA_DIR, 'ekc_co2_real.csv'))
            datasets['ekc'] = len(ekc)

        demo_trans = get_demographic_transition_real(wb_data)
        if demo_trans is not None:
            demo_trans.to_csv(os.path.join(DATA_DIR, 'demographic_transition_real.csv'))
            datasets['demographic_transition'] = len(demo_trans)

        forest = get_forest_transition_real(wb_data)
        if forest is not None:
            forest.to_csv(os.path.join(DATA_DIR, 'forest_transition_real.csv'))
            datasets['forest_transition'] = len(forest)

        print(f"\n  Real datasets extracted: {datasets}")

    # 4. Create source metadata
    create_source_metadata()

    print("\n" + "=" * 60)
    print("DATA FETCH COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    main()
