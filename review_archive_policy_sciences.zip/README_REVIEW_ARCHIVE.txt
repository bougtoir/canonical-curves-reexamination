Policy Sciences anonymous reproducibility archive

Contents
- data/, results/, scripts/: cross-domain mapping data, outputs, and analysis code.
- quasi_experiments/kansas/: Kansas source snapshots, processed data, code, and outputs.
- quasi_experiments/fukushima/: Fukushima source snapshots, processed data, code, and outputs.
- quasi_experiments/manuscript/: anonymized manuscript text and document generator.
- data/source_manifest.csv: cross-domain input paths, sizes, SHA-256 hashes,
  source URLs, timestamp basis, acquisition notes, and usage terms.
- quasi_experiments/*/data/raw_manifest.csv: source paths, sizes, SHA-256 hashes,
  timestamp basis, acquisition notes, and usage terms.

Reproduction
1. Create an isolated Python environment.
2. Install pinned packages:
   pip install -r requirements.txt
3. Rebuild the cross-domain mapping:
   python scripts/run_all_analyses.py
   python scripts/verdict_sensitivity.py
4. Rebuild the policy demonstrations and manuscript from this archive root:
   cd quasi_experiments
   make manuscript

Exact historical request times were not retained. The machine-readable
manifests therefore label the first repository commit as a UTC timestamp proxy.
One unused legacy Fukushima workbook predates the ledger and is not read by the
current analysis.
