# Final handoff

- Final title: Functional-Form Dependence in Evidence-Based Policymaking: Mapping Canonical Relationships and Two Policy Demonstrations
- Abstract word count: 221
- Main-text word count, excluding abstract, references, captions, and tables: 6172
- Figures: 7 main figures plus Appendix Figure A1
- Tables: 4 main tables plus Appendix Tables A1 and A2
- Figure numbering: Figure 1 decision-facing framework; Figure 2 mapping diagnostic; Figure 3 sensitivity grid; Figures 4-6 Fukushima; Figure 7 Kansas; Appendix Figure A1 Kansas neighboring-state event studies
- Inline manuscript: Policy_Sciences_manuscript_inline_FINAL.docx
- Clean separate-figure manuscript: Policy_Sciences_manuscript_clean_FINAL.docx
- Cover letter: Policy_Sciences_cover_letter_FINAL.docx
- Title page: Policy_Sciences_title_page_FINAL.docx
- Supplement: Policy_Sciences_appendix_FINAL.docx
- Editable tables: Policy_Sciences_tables_FINAL.docx
- Editable figures: Policy_Sciences_figures_FINAL.pptx
- Submission statements: Policy_Sciences_submission_statements_FINAL.docx
- Remaining author-local placeholders: None. Confirm the author name, affiliation, and corresponding-author email in the submission portal against the separate title page.
- Unresolved scientific concern: No submission-blocking concern. The non-probability mapping, Fukushima measurement structure, and Kansas residual-confounding limits remain and are stated explicitly.

## Framework-count inconsistency

- Locations checked: Abstract, Introduction, analytical framework, Figure 1 caption, Discussion, Conclusion, cover letter, and hostile-review record.
- Exact wording changed: "The framework distinguishes six layers." to "The decision-facing appraisal framework distinguishes linked layers from empirical association through policy commitment."
- Exact wording changed: "Figure 1 introduced the six-step sequence before the empirical demonstrations." to "Figure 1 introduced the decision-facing appraisal framework before the empirical demonstrations."
- Exact wording changed: "The article develops a six-step appraisal framework" to "The article develops a decision-facing appraisal framework."
- The shared term across the Abstract, Introduction, Figure 1, Discussion, Conclusion, and cover letter is "decision-facing appraisal framework."

## AI declaration

Exact final wording:

> An AI coding assistant (Devin, Cognition AI) was used to assist with data-acquisition, analysis, and document-generation code and with manuscript drafting and editing under the author's direction. The author specified the research questions and analytical choices, verified the data sources and results, evaluated all interpretations, and takes full responsibility for the manuscript.

Files containing it: Policy_Sciences_manuscript_inline_FINAL.docx, Policy_Sciences_manuscript_clean_FINAL.docx, Policy_Sciences_title_page_FINAL.docx, and Policy_Sciences_submission_statements_FINAL.docx. The cover letter does not repeat it because the journal materials used for this package do not require disclosure there.

## Numerical results

No numerical results changed.

## Figure/table numbering

Unchanged: seven main figures, Appendix Figure A1, four main tables, and Appendix Tables A1 and A2.

## References

No reference was altered.

READY FOR POLICY SCIENCES SUBMISSION
