# Final handoff

- Final title: When Policy Depends on a Curve: Comparing Functional-Form Dependence in Fukushima Evacuation and Kansas Tax Reform
- Article type: Original research article (explicitly comparative)
- Abstract word count: 94
- Manuscript word count (all inclusive, per docx check): 6384
- Main-text word count, excluding abstract, references, captions, and
  tables: 3120
- Figures: 7 main figures plus Appendix Figure A1
- Tables: 5 main tables plus Appendix Tables A1 and A2
- Figure numbering: Figure 1 comparative appraisal sequence; Figure 2
  mapping diagnostic; Figure 3 sensitivity grid; Figures 4-6 Fukushima;
  Figure 7 Kansas; Appendix Figure A1 Kansas neighboring-state event
  studies
- Exact comparative research question: how does functional-form
  dependence enter policy decisions under substantively different
  evidentiary, institutional, and consequence structures, and what can
  comparison across those structures teach us about policy appraisal
  under uncertainty?
- Case-selection logic: maximum substantive contrast (radiation
  protection vs. fiscal policy) with a common decision-level mechanism
  (commitment resting on incompletely identified functional form).
- Principal comparative finding: the same mechanism appears in both
  cases, but its policy significance depends on the joint configuration
  of decision sensitivity, consequence asymmetry, reversibility,
  transportability, and learning capacity.
- Appendix integration: 2 Appendix Tables (A1, A2) and 1 Appendix Figure
  (A1) embedded in the manuscript Appendix section; numbering unchanged;
  no values changed; the separate appendix file is retained internally
  only and is NOT required for submission.
- Formatting pass: 12 pt Times New Roman body, double-spaced manuscript,
  minimal horizontal table rules, abstract 94 words (<=100).
- Inline manuscript: JCPA_manuscript_inline_FINAL_WITH_APPENDIX_FORMATTED_V2.docx
- Clean separate-figure manuscript: JCPA_manuscript_clean_FINAL_WITH_APPENDIX_FORMATTED_V2.docx
- Cover letter: JCPA_cover_letter_FINAL.docx
- Title page: JCPA_title_page_FINAL.docx
- Editable tables: JCPA_tables_FINAL.docx
- Editable figures: JCPA_figures_FINAL.pptx
- Submission statements: JCPA_submission_statements_FINAL.docx
- Files to upload to JCPA: inline manuscript DOCX (or clean version per
  portal), cover letter, title page, editable figures PPTX, editable
  tables DOCX, submission statements.

## Major changes from the Policy Studies version

- Rebuilt around an explicit structured focused comparison: new
  Comparative research design section (case selection, units and common
  dimensions, evidence, inferential limits), parallel seven-subsection
  case structure, dedicated Comparative findings section with a
  Comparative-lesson column in Table 5, three comparative propositions,
  and a dedicated lesson-drawing subsection.
- New comparative title, abstract, introduction architecture, and JCPA
  cover letter; discussion reorganized around the comparative finding.
- The 50-relationship mapping is repositioned as background motivation,
  not as the comparative core.

## Literature changes

- Added: Bennett & Howlett (1992); Dolowitz & Marsh (2000); Freeman
  (2006); George & Bennett (2005); Hall (1993); Przeworski & Teune
  (1970); Rose (1991).
- Removed (unused after restructuring): Autor (2003); Capano &
  Malandrino (2022); Capano & Woo (2017); Dunlop (2010); Head (2008);
  Kolkman et al. (2016); Saltelli et al. (2020); Wesselink et al.
  (2014); Cartwright & Hardie (2012).

## Analyses and numbers

No analysis, dataset, or numerical result changed. All values are
injected from numbers.json; the analysis freeze was respected.

## Remaining limitations

- Two purposive cases; retrospective reconstruction; no statistical
  generalization; Fukushima measurement structure and Kansas residual
  confounding limits remain and are stated explicitly.
- None. Confirm the author name, affiliation, and corresponding-author email in the submission portal against the separate title page; the affiliation field is intentionally left for the submitting author.

EXPLICITLY COMPARATIVE: YES

READY FOR JCPA RESUBMISSION
